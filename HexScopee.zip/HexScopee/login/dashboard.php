<?php
session_start();
if(!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Test Area</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }
        .success-box {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
        }
        .info-box {
            background: #e7f3ff;
            color: #2c5282;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid #bee3f8;
        }
        .method-box {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid #dee2e6;
        }
        .method-box h3 {
            color: #495057;
            margin-bottom: 10px;
        }
        .method-box pre {
            background: #343a40;
            color: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
            font-size: 14px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #dc3545;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
            transition: background 0.3s;
        }
        .btn:hover {
            background: #c82333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        th {
            background: #667eea;
            color: white;
        }
        tr:hover {
            background: #f8f9fa;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎉 Login Successful!</h1>
        
        <div class="success-box">
            <strong>Welcome, <?php echo htmlspecialchars($_SESSION['user']); ?>!</strong><br>
            Login Time: <?php echo $_SESSION['login_time']; ?>
        </div>
        
        <div class="info-box">
            <strong>🔐 Aap Vulnerable Login Page mein hain!</strong><br>
            Yahan aap alag-alag attack techniques test kar sakte hain:
            <ul style="margin-top: 10px; margin-left: 20px;">
                <li>SQL Injection</li>
                <li>NoSQL Injection</li>
                <li>Brute Force</li>
                <li>JSON Payload Attacks</li>
            </ul>
        </div>
        
        <div class="method-box">
            <h3>📝 Ab aap Burp Suite mein ye requests try karein:</h3>
            <pre>
# Normal POST request
POST /login/login.php HTTP/1.1
Host: localhost
Content-Type: application/x-www-form-urlencoded
Content-Length: 28

username=admin&password=admin123

# JSON request
POST /login/login.php HTTP/1.1
Host: localhost
Content-Type: application/json

{"username":"admin","password":"admin123"}

# SQL Injection
POST /login/login.php HTTP/1.1
Host: localhost
Content-Type: application/x-www-form-urlencoded

username=admin&password=' OR '1'='1

# NoSQL Injection
POST /login/login.php HTTP/1.1
Host: localhost
Content-Type: application/json

{"username":"admin","password":{"$ne":""}}
            </pre>
        </div>
        
        <h2>📊 Login Attempt Log</h2>
        <table>
            <thead>
                <tr>
                    <th>Time</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if(file_exists('login_attempts.log')) {
                    $lines = file('login_attempts.log');
                    $lines = array_reverse($lines);
                    $count = 0;
                    foreach($lines as $line) {
                        if($count >= 10) break;
                        $parts = explode(' | ', $line);
                        if(count($parts) >= 4) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($parts[0]) . "</td>";
                            echo "<td>" . htmlspecialchars(str_replace('User: ', '', $parts[1])) . "</td>";
                            echo "<td>" . htmlspecialchars(str_replace('Pass: ', '', $parts[2])) . "</td>";
                            echo "<td>" . htmlspecialchars(str_replace('Status: ', '', $parts[3])) . "</td>";
                            echo "</tr>";
                        }
                        $count++;
                    }
                }
                ?>
            </tbody>
        </table>
        
        <div style="margin-top: 30px; text-align: right;">
            <a href="logout.php" class="btn">Logout</a>
        </div>
    </div>
</body>
</html>