<?php
session_start();

// Function to log attempts (for monitoring)
function logAttempt($username, $password, $status) {
    $log = date('Y-m-d H:i:s') . " | User: $username | Pass: $password | Status: $status\n";
    file_put_contents('login_attempts.log', $log, FILE_APPEND);
}

// Get input
$username = isset($_POST['username']) ? $_POST['username'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// ============================================
// VULNERABILITY 1: SQL Injection (simulated)
// ============================================
// Database mein actually data nahi hai, hum simulate kar rahe hain
$valid_credentials = [
    'admin' => 'admin123',
    'user' => 'password',
    'test' => 'test123',
    'toolsbug' => 'toolsbug@123'
];

// ============================================
// VULNERABILITY 2: NoSQL Injection Simulation
// ============================================
// Agar JSON input ho to handle karein
$content_type = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
if(strpos($content_type, 'application/json') !== false) {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    if($data) {
        $username = isset($data['username']) ? $data['username'] : $username;
        $password = isset($data['password']) ? $data['password'] : $password;
    }
}

// ============================================
// VULNERABILITY 3: Authentication Bypass
// ============================================
$authenticated = false;

// Case 1: SQL Injection pattern (simulated)
if(is_string($password) && strpos($password, "' OR '1'='1") !== false) {
    $authenticated = true;
    logAttempt($username, $password, "SQL_INJECTION_BYPASS");
}
// Case 2: NoSQL pattern (simulated)
elseif(is_array($password) && isset($password['$ne'])) {
    $authenticated = true;
    logAttempt($username, json_encode($password), "NOSQL_INJECTION_BYPASS");
}
// Case 3: Empty password bypass
elseif($password === "") {
    $authenticated = false; // Isko intentionally false rakha hai
}
// Case 4: Normal credential check
elseif(isset($valid_credentials[$username]) && $valid_credentials[$username] === $password) {
    $authenticated = true;
    logAttempt($username, $password, "SUCCESS");
}
// Case 5: Type confusion (boolean true)
elseif($password === true || $password === "true") {
    $authenticated = true;
    logAttempt($username, "BOOLEAN_TRUE", "TYPE_CONFUSION");
}
else {
    logAttempt($username, $password, "FAILED");
}

// ============================================
// Response based on authentication
// ============================================
if($authenticated) {
    $_SESSION['user'] = $username;
    $_SESSION['login_time'] = date('Y-m-d H:i:s');
    
    // Check if it's an AJAX/JSON request
    if(isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'message' => 'Login successful!',
            'redirect' => 'dashboard.php'
        ]);
    } else {
        header("Location: dashboard.php");
    }
    exit();
} else {
    // Failed login
    if(isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) {
        header('HTTP/1.1 401 Unauthorized');
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'detail' => 'Invalid credentials'
        ]);
    } else {
        header("Location: index.php?error=" . urlencode("Invalid credentials"));
    }
    exit();
}
?>